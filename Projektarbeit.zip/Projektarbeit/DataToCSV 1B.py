import os
import csv
import json

# Set the base directory where the generated files are stored
base_dir = '/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/Outputs/llama-3.2-1b-instruct'

# Output CSV file path
output_csv = '/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/Outputs/llama-3.2-1b-instruct/output_data.csv'

# Prepare the CSV file with headers
with open(output_csv, 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['Author', 'TextType', 'Length', 'Filename', 'Content']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    # Loop through each TextType directory (Letter, Parabel, Gedicht)
    for text_type_dir in os.listdir(base_dir):
        text_type_path = os.path.join(base_dir, text_type_dir)
        if os.path.isdir(text_type_path):
            
            # Loop through each Author directory (inside TextType)
            for author_dir in os.listdir(text_type_path):
                author_path = os.path.join(text_type_path, author_dir)
                if os.path.isdir(author_path):
                    author_name = author_dir  # This should be the Author

                    # Loop through each Length directory (L100, L250, L400)
                    for length_dir in os.listdir(author_path):
                        length_path = os.path.join(author_path, length_dir)
                        if os.path.isdir(length_path):
                            length = length_dir.replace('L', '')  # Remove 'L' from length (L100 -> 100)

                            # Loop through each text file in the Length folder
                            for file_name in os.listdir(length_path):
                                if file_name.endswith('.txt'):
                                    file_path = os.path.join(length_path, file_name)

                                    # Read the content of the file
                                    with open(file_path, 'r', encoding='utf-8') as f:
                                        try:
                                            # Load the JSON content to extract only the text
                                            data = json.load(f)
                                            content = data['choices'][0]['message']['content'].replace('\n', ' ').replace('\r', '')
                                        except json.JSONDecodeError:
                                            content = ""  # In case there's a parsing error

                                    # Write to CSV file
                                    writer.writerow({
                                        'Author': author_name,
                                        'TextType': text_type_dir,  # This is the TextType (Gedicht, Brief, Parabel)
                                        'Length': length,
                                        'Filename': file_name,
                                        'Content': content
                                    })

print(f"CSV file has been generated: {output_csv}")
