import os
import json
import re

# Base directory where the raw output files are stored
raw_input_base = '/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/Outputs/llama-3.2-1b-instruct'

# Define the text types (folder names) to process
text_types = ['Letter', 'Poem', 'Parabola']

# Define abbreviations for each text type for new file naming
abbr_map = {
    'Letter': 'Ltr',
    'Poem': 'Poe',
    'Parabola': 'Par'
}

# Function to create a new filename from the raw filename and folder info
def create_new_filename(raw_filename, text_type, author):
    parts = raw_filename.split('_')
    abbr = abbr_map.get(text_type, text_type[:3])
    author_last = author.split()[-1]
    topic = parts[2] if len(parts) >= 3 else "Topic"
    length_part = parts[3] if len(parts) >= 4 else "L000"
    file_num = parts[4].replace('.txt', '') if len(parts) >= 5 else "0"
    new_filename = f"{abbr}_{author_last}_{topic}_{length_part}_{file_num}.txt"
    return new_filename

# Function to clean the content from a raw JSON file:
def clean_file_content(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        content = data['choices'][0]['message']['content']
        cleaned = re.sub(r'\s+', ' ', content).strip()
        return cleaned
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return ""

# Create target folder for all filtered files
target_filtered_dir = os.path.join(raw_input_base, "Filtered")
os.makedirs(target_filtered_dir, exist_ok=True)

# Process each text type folder
for text_type in text_types:
    # Source directory for this text type
    source_type_dir = os.path.join(raw_input_base, text_type)
    if not os.path.isdir(source_type_dir):
        print(f"Skipping missing folder: {source_type_dir}")
        continue

    # Loop through each author folder within this text type
    for author in os.listdir(source_type_dir):
        author_source_dir = os.path.join(source_type_dir, author)
        if not os.path.isdir(author_source_dir):
            continue
        
        # Create corresponding author folder in Filtered directory
        author_target_dir = os.path.join(target_filtered_dir, text_type, author)
        os.makedirs(author_target_dir, exist_ok=True)

        # Loop through each length folder (e.g., L100, L250, L400)
        for length in os.listdir(author_source_dir):
            length_source_dir = os.path.join(author_source_dir, length)
            if not os.path.isdir(length_source_dir):
                continue

            # Create corresponding length folder in target
            length_target_dir = os.path.join(author_target_dir, length)
            os.makedirs(length_target_dir, exist_ok=True)

            # Loop through each file in this length folder
            for filename in os.listdir(length_source_dir):
                raw_file_path = os.path.join(length_source_dir, filename)
                if not os.path.isfile(raw_file_path):
                    continue

                # Create a new filename using our function
                new_filename = create_new_filename(filename, text_type, author)
                target_file_path = os.path.join(length_target_dir, new_filename)
                
                # Clean the content of the file
                cleaned_text = clean_file_content(raw_file_path)
                
                # Write the cleaned text to the new file in plain text format
                with open(target_file_path, 'w', encoding='utf-8') as out_file:
                    out_file.write(cleaned_text)
                
                print(f"Processed {raw_file_path} -> {target_file_path}")

print("Processing complete!")
