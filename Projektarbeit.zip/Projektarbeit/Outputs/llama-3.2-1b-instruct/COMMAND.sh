#!/bin/bash

# Autoren und ihre System-Prompts für Englisch, inklusive Standard-Modell
authors=("Standard" "William Shakespeare" "Charles Dickens" "Jane Austen" "George Orwell" "Virginia Woolf" "Emily Dickinson" "Mark Twain" "Herman Melville")

# Englische Prompts für Gedicht, Brief und Parabel mit Länge
prompts_en_gedicht=("Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of"
                    "Write a poem about the meaning of freedom with a maximum length of")

prompts_en_brief=("Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of"
                 "Write a letter about the meaning of freedom with a maximum length of")

prompts_en_parabel=("Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of"
                   "Write a parable about the meaning of freedom with a maximum length of")

# Anzahl der Ausgaben pro Texttyp und Längenkategorie
outputs_per_type=50

# Überordner für das Modell erstellen
model_dir="llama-3.2-1b-instruct"
base_dir="/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/Outputs/$model_dir"
mkdir -p "$base_dir"

# Ordner erstellen und Ausgaben generieren
for i in ${!authors[@]}; do
  author="${authors[$i]}"

  # Generiere Gedicht, Brief und Parabel für den jeweiligen Autor
  for type in "Gedicht" "Brief" "Parabel"; do
    # Englische Prompts zuordnen
    if [ "$type" == "Gedicht" ]; then
      base_prompt="${prompts_en_gedicht[$i]}"
    elif [ "$type" == "Brief" ]; then
      base_prompt="${prompts_en_brief[$i]}"
    elif [ "$type" == "Parabel" ]; then
      base_prompt="${prompts_en_parabel[$i]}"
    fi

    # Ordner für den Texttyp, den Autor und die Länge erstellen
    for length in 100 250 400; do
      output_dir="${base_dir}/${type}/${author}/L${length}"
      mkdir -p "$output_dir"

      for j in $(seq 1 $outputs_per_type); do
        # Dateiname erstellen
        output_file="${output_dir}/${type}_${author}_Freedom_L${length}_${j}.txt"

        # Hier wird max_tokens um 50, damit der Prompt vollständig verarbeitet wird
        adjusted_max_tokens=$((length + 50))

        # Finalen Prompt mit Längenangabe und Autor als Systemanweisung zusammensetzen
        full_prompt="YOU ARE $author. $base_prompt ${length} tokens."

        # Generiere den Text
        curl -X POST http://localhost:1234/api/v0/chat/completions \
          -H "Content-Type: application/json" \
          -d '{
            "model": "llama-3.2-1b-instruct",
            "messages": [
              {"role": "system", "content": "'"$full_prompt"'"},
              {"role": "user", "content": "Please generate the requested text."}
            ],
            "max_tokens": '"$adjusted_max_tokens"'
          }' > "$output_file"

        # Bestätigung im Terminal
        echo "Text for $author ($type) with $length tokens, output $j saved to $output_file."
      done
    done
  done
done


# Author: Lev Roth