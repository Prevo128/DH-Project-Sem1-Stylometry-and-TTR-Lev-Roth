library(tidyverse)
library(readtext)
library(stringr)
library(ggplot2)

# Definieren der Pfade zu den 1B und 3B gefilterten Verzeichnissen
path_1B <- '/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/Outputs/llama-3.2-1b-instruct/Filtered/1B/'
path_3B <- '/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/Outputs/llama-3.2-1b-instruct/Filtered/3B/'

# Funktion zum Lesen von Textdateien aus dem Verzeichnis
read_texts_from_directory <- function(base_path) {
  text_types <- c('Letter', 'Poem', 'Parable') 
  all_texts <- list()
  
  for (text_type in text_types) {
    text_type_path <- file.path(base_path, text_type)
    
    for (author in list.dirs(text_type_path, full.names = TRUE, recursive = FALSE)) {
      author_name <- basename(author)
      
      for (length in list.dirs(author, full.names = TRUE, recursive = FALSE)) {
        length_name <- basename(length)
        
        files <- list.files(length, full.names = TRUE, pattern = "\\.txt$")
        
        for (file in files) {
          text <- readtext(file)$text
          
          all_texts <- append(all_texts, list(list(
            text_type = text_type,
            author = author_name,
            length = length_name,
            model = ifelse(grepl('1B', base_path), '1B', '3B'),
            file_path = file,
            text = text
          )))
        }
      }
    }
  }
  
  return(all_texts)
}

# Texte aus beiden 1B und 3B Verzeichnissen lesen
texts_1B <- read_texts_from_directory(path_1B)
texts_3B <- read_texts_from_directory(path_3B)

# Kombinieren die Daten aus beiden Modellen
texts <- c(texts_1B, texts_3B)

# Erstellen eines DataFrames aus der Liste
df <- bind_rows(lapply(texts, function(x) data.frame(
  text_type = x$text_type,
  author = x$author,
  length = x$length,
  model = x$model,
  file_path = x$file_path,
  text = x$text
)))

# Sortiert Autoren, sodass "Standard" immer zuerst erscheint
df$author <- factor(df$author, levels = c("Standard", unique(df$author[df$author != "Standard"])))

# Berechnet TTR
df <- df %>%
  mutate(
    tokens = str_split(text, "\\s+"),
    n_tokens = lengths(tokens),
    n_types = sapply(tokens, function(x) length(unique(x))),
    ttr = n_types / n_tokens
  )

# Funktion zum Berechnen und Beschriften von Q1, Q3, Median
add_quartile_labels <- function(plot) {
  plot + 
    stat_summary(fun = median, geom = "text", aes(label = sprintf("%.3f", ..y..)), 
                 position = position_nudge(y = 0.02), color = "black", size = 3) +
    stat_summary(fun = function(x) quantile(x, 0.25), geom = "text", aes(label = sprintf("Q1: %.3f", ..y..)), 
                 position = position_nudge(x = 0.25, y = -0.015), color = "#4d4d4d", size = 3) +
    stat_summary(fun = function(x) quantile(x, 0.75), geom = "text", aes(label = sprintf("Q3: %.3f", ..y..)), 
                 position = position_nudge(x = 0.25, y = 0.015), color = "#4d4d4d", size = 3)
}

# Plot TTR vs Length vs Model
ttr_length_model_plot <- ggplot(df, aes(x = length, y = ttr, fill = model)) +
  geom_boxplot(size = 0.33) +
  facet_grid(. ~ model) +
  labs(title = "TTR vs Length vs Model",
       x = "Length (L100, L250, L400)",
       y = "Type-Token Ratio (TTR)") +
  scale_y_continuous(limits = c(0.50, 1.00), breaks = seq(0.50, 1.00, by = 0.05)) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) 

ttr_length_model_plot <- add_quartile_labels(ttr_length_model_plot)

# TTR Plot vs Author vs Model
ttr_author_model_plot <- ggplot(df, aes(x = author, y = ttr, fill = model)) +
  geom_boxplot(size = 0.33) +
  facet_grid(. ~ model) +
  labs(title = "TTR vs Author vs Model",
       x = "Author",
       y = "Type-Token Ratio (TTR)") +
  scale_y_continuous(limits = c(0.50, 1.00), breaks = seq(0.50, 1.00, by = 0.05)) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) 

ttr_author_model_plot <- add_quartile_labels(ttr_author_model_plot)

# Plot TTR vs Text Type vs Model
ttr_text_type_model_plot <- ggplot(df, aes(x = text_type, y = ttr, fill = model)) +
  geom_boxplot(size = 0.33) +
  facet_grid(. ~ model) +
  labs(title = "TTR vs Text Type vs Model",
       x = "Text Type (Letter, Poem, Parable)",
       y = "Type-Token Ratio (TTR)") +
  scale_y_continuous(limits = c(0.50, 1.00), breaks = seq(0.50, 1.00, by = 0.05)) +
  theme_minimal()

ttr_text_type_model_plot <- add_quartile_labels(ttr_text_type_model_plot)

# Plot TTR vs Model vs Text Type vs Length
ttr_model_text_type_length_plot <- ggplot(df, aes(x = model, y = ttr, fill = model)) +
  geom_boxplot(size = 0.33) +
  facet_grid(text_type ~ length) +
  labs(title = "TTR vs Model vs Text Type vs Length",
       x = "Model",
       y = "Type-Token Ratio (TTR)") +
  scale_y_continuous(limits = c(0.50, 1.00), breaks = seq(0.50, 1.00, by = 0.05)) +
  theme_minimal()

ttr_model_text_type_length_plot <- add_quartile_labels(ttr_model_text_type_length_plot)

# Alle Plots anzeigen
print(ttr_length_model_plot)
print(ttr_author_model_plot)
print(ttr_text_type_model_plot)
print(ttr_model_text_type_length_plot)

# Berechnen und Erstellen einer Liste mit den relevanten TTR-Daten für eine CSV-Datei, falls nötig
ttr_summary_list <- df %>%
  select(text_type, author, length, model, ttr) %>%
  arrange(author, text_type, length, model) %>%
  group_by(author, text_type, length, model) %>%
  summarise(
    mean_ttr = round(mean(ttr), 3),  # Durchschnittlicher TTR
    median_ttr = round(median(ttr), 3),  # Median TTR
    sd_ttr = round(sd(ttr), 3),  # Standardabweichung des TTR
    q1_ttr = round(quantile(ttr, 0.25), 3),  # Q1 (25. Perzentil)
    q3_ttr = round(quantile(ttr, 0.75), 3),  # Q3 (75. Perzentil)
    .groups = 'drop'
  ) %>%
  # Erstelle Spalten für das Quartillabel
  mutate(
    iqr = round(q3_ttr - q1_ttr, 3),  # --> Interquartilsabstand
    label = paste("Q1: ", q1_ttr, " - Q3: ", q3_ttr, " (IQR: ", iqr, ")", sep = "")
  )

# Ausgabe der zusammengefassten TTR-Daten als strukturiertes DataFrame
print(ttr_summary_list)

# Speichern der TTR-Daten als CSV-Datei
write.csv(ttr_summary_list, "/Users/lev/Desktop/Uni/DH/Semester 1/Projektarbeit/ttr_summary_data.csv", row.names = FALSE)

# Rückgabe der TTR-Liste
ttr_summary_list


#Author: Lev Roth